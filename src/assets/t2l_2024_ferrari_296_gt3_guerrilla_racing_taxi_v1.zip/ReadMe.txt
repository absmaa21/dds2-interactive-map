Assetto Corsa Competizione 2024 Ferrari 296 GT3 Guerrilla Racing Taxi livery

Version 1.0

Extract the "Assetto Corsa Competizione" folder to your "My Documents"

Should look something like this:

C:\Users\**your windows user name**\Documents\

Changelog

v1.0
Initial release

Enjoy!

Cheers

Günthar Rowe
True2Life-Racing Designs
https://www.paypal.me/true2liferacing     <<<< buy me a beer if you like it :)